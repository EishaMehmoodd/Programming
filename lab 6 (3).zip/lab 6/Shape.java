public  enum Shape{

    RECTANGLE,TRAPEZOID,L_SHAPE;






}


public class Screen {
    private String screenName;
    private Seat[][] seats;

    public static final double PRICE_REGULAR = 500.0;
    public static final double PRICE_PREMIUM = 750.0;
    public static final double PRICE_VIP = 1000.0;
    public static final double PRICE_RECLINER = 1200.0;

    private static final int DEFAULT_NUM_ROWS = 5;

    public Screen(String name, int[] rowLengths) {
        this.screenName = name;
        buildSeats(rowLengths);
    }

    public Screen(String name) {
        this(name, buildDefaultRowLengths(DEFAULT_NUM_ROWS));
    }

    private static int[] buildDefaultRowLengths(int numRows) {
        int[] arr = new int[numRows];
        for (int i = 0; i < numRows; i++) arr[i] = 10 + i;
        return arr;
    }

    private void buildSeats(int[] rowLengths) {
        seats = new Seat[rowLengths.length][];
        for (int r = 0; r < rowLengths.length; r++) {
            int len = rowLengths[r];
            seats[r] = new Seat[len];
            SeatType rowType = seatTypeFor(r, rowLengths.length);
            double price = priceFor(rowType);
            for (int c = 0; c < len; c++) {
                String id = String.format("%d-%03d", r + 1, c + 1);
                seats[r][c] = new Seat(id, rowType, price);
            }
        }
    }

    public String getScreenName() { return screenName; }

    public Seat getSeat(int row, int col) {
        if (row < 1 || row > seats.length) return null;
        if (col < 1 || col > seats[row - 1].length) return null;
        return seats[row - 1][col - 1];
    }

    public Seat getSeat(String id) {
        for (Seat[] row : seats)
            for (Seat s : row)
                if (s.getId().equals(id)) return s;
        return null;
    }

    public boolean book(String id) {
        Seat s = getSeat(id);
        return s != null && s.book();
    }

    public boolean book(int row, int col) {
        Seat s = getSeat(row, col);
        return s != null && s.book();
    }

    public boolean cancel(String id) {
        Seat s = getSeat(id);
        return s != null && s.cancel();
    }

    public boolean cancel(int row, int col) {
        Seat s = getSeat(row, col);
        return s != null && s.cancel();
    }

    public int getTotalSeatCount() {
        int sum = 0;
        for (Seat[] row : seats) sum += row.length;
        return sum;
    }

    public int getAvailableSeatCount() {
        int sum = 0;
        for (Seat[] row : seats)
            for (Seat s : row)
                if (s.isAvailable()) sum++;
        return sum;
    }

    public int getAvailableSeatCount(SeatType t) {
        int sum = 0;
        for (Seat[] row : seats)
            for (Seat s : row)
                if (s.getType() == t && s.isAvailable()) sum++;
        return sum;
    }

    public Seat[] listAvailable(SeatType t) {
        int count = 0;
        for (Seat[] row : seats)
            for (Seat s : row)
                if (s.getType() == t && s.isAvailable()) count++;
        Seat[] result = new Seat[count];
        int idx = 0;
        for (Seat[] row : seats)
            for (Seat s : row)
                if (s.getType() == t && s.isAvailable()) result[idx++] = s;
        return result;
    }

    public Seat findFirstAvailable(SeatType t) {
        for (Seat[] row : seats)
            for (Seat s : row)
                if (s.getType() == t && s.isAvailable()) return s;
        return null;
    }

public void displayLayout() {
    System.out.println("=== Screen: " + screenName + " | Layout ===");
    int total = 0, available = 0;
    for (int r = 0; r < seats.length; r++) {
        StringBuilder sb = new StringBuilder();
        for (Seat s : seats[r]) {
            sb.append(String.format("[%s:%s] ",
                    s.getId(), (s.isAvailable() ? "A" : "X")));
            total++;
            if (s.isAvailable()) available++;
        }
        System.out.println(sb.toString().trim());
    }
    System.out.println("Total: " + total + ", Available: " + available);
}

    public void displayVerbose() {
        System.out.println("Detailed seats for " + screenName + ":");
        for (Seat[] row : seats)
            for (Seat s : row)
                System.out.println(s);
    }

    public int getRowCount() { return seats.length; }

    public SeatType seatTypeFor(int rowIndex, int totalRows) {
        if (rowIndex == totalRows - 1) return SeatType.RECLINER;
        if (rowIndex == totalRows - 2) return SeatType.VIP;
        if (rowIndex == totalRows / 2) return SeatType.PREMIUM;
        if (rowIndex < totalRows / 2) return SeatType.REGULAR;
        return SeatType.PREMIUM;
    }

    public double priceFor(SeatType t) {
        switch (t) {
            case REGULAR: return PRICE_REGULAR;
            case PREMIUM: return PRICE_PREMIUM;
            case VIP: return PRICE_VIP;
            case RECLINER: return PRICE_RECLINER;
            default: return PRICE_REGULAR;
        }
    }
}
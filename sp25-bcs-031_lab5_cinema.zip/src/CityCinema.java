
public class CityCinema {
    private String cityName;
    private Cinema[] cinemas;
    private int size;

    public CityCinema(String cityName, int initialCapacity) {
        this.cityName = cityName;
        this.cinemas = new Cinema[Math.max(1, initialCapacity)];
        this.size = 0;
    }

    public CityCinema(String cityName) { this(cityName, 4); }

    public String getCityName() { return cityName; }

    public void addCinema(Cinema c) {
        if (size == cinemas.length) {
            Cinema[] nc = new Cinema[cinemas.length * 2];
            for (int i = 0; i < cinemas.length; i++) nc[i] = cinemas[i];
            cinemas = nc;
        }
        cinemas[size++] = c;
    }

    public Cinema findCinemaByName(String n) {
        for (int i = 0; i < size; i++)
            if (cinemas[i].getName().equalsIgnoreCase(n)) return cinemas[i];
        return null;
    }

    public boolean book(String cinemaName, String screenName, String seatId) {
        Cinema c = findCinemaByName(cinemaName);
        return c != null && c.book(screenName, seatId);
    }

    public boolean cancel(String cinemaName, String screenName, String seatId) {
        Cinema c = findCinemaByName(cinemaName);
        return c != null && c.cancel(screenName, seatId);
    }

    public String findFirstAvailableVIP() {
        for (int i = 0; i < size; i++) {
            Cinema c = cinemas[i];
            for (int si = 0; ; si++) {
                Screen sc = c.findScreenByIndex(si);
                if (sc == null) break;
                Seat s = sc.findFirstAvailable(SeatType.VIP);
                if (s != null)
                    return String.format("%s > %s > %s (%s, %.2f PKR)",
                            c.getName(), sc.getScreenName(), s.getId(),
                            s.getType(), s.getPrice());
            }
        }
        return "No available VIP seat found";
    }

    public static CityCinema preloadCity(String cityName, String[] cinemaNames) {
        CityCinema city = new CityCinema(cityName, cinemaNames.length);
        for (String cn : cinemaNames) {
            Cinema cin = new Cinema(cn, 3);
            cin.addScreen(new Screen("Screen-1"));
            cin.addScreen(new Screen("Screen-2"));
            city.addCinema(cin);
        }
        return city;
    }public void printCompactCity() {
    System.out.println("=== CITY: " + cityName + " | All Cinema Layouts ===");
    for (int i = 0; i < size; i++) {
        cinemas[i].printCompactAllScreens();
    }
}
}

public class SeatDemo {
    public static void main(String[] args) {

        System.out.println("=== CITY: Karachi | Seat Demo Layout ===");
        System.out.println("=== CINEMA: Demo Cinema | Layout ===");
        System.out.println("=== Screen-1 | Layout ===");

        // build a screen exactly like assignment default
        int[] rowLengths = {10, 11, 12, 13, 14}; // total 60 seats
        Seat[][] layout = new Seat[rowLengths.length][];

        for (int r = 0; r < rowLengths.length; r++) {
            layout[r] = new Seat[rowLengths[r]];
            for (int c = 0; c < rowLengths[r]; c++) {
                String id = String.format("%d-%03d", r + 1, c + 1);
                SeatType type = SeatType.REGULAR;
                double price = Screen.PRICE_REGULAR;

                // assign seat types like Screen does
                if (r == rowLengths.length - 1) type = SeatType.RECLINER;
                else if (r == rowLengths.length - 2) type = SeatType.VIP;
                else if (r == rowLengths.length / 2) type = SeatType.PREMIUM;
                else if (r < rowLengths.length / 2) type = SeatType.REGULAR;
                else type = SeatType.PREMIUM;

                switch (type) {
                    case REGULAR -> price = Screen.PRICE_REGULAR;
                    case PREMIUM -> price = Screen.PRICE_PREMIUM;
                    case VIP -> price = Screen.PRICE_VIP;
                    case RECLINER -> price = Screen.PRICE_RECLINER;
                }

                layout[r][c] = new Seat(id, type, price);
            }
        }

        // initial layout
        printLayout(layout);

        // Booking seat 3-007
        System.out.println("\nBooking seat 3-007...");
        findSeat(layout, "3-007").book();
        printLayout(layout);

        // Attempt double booking
        System.out.println("\nAttempt double booking for 3-007...");
        boolean success = findSeat(layout, "3-007").book();
        System.out.println("Booking success: " + success);
        printLayout(layout);

        // Cancel booking
        System.out.println("\nCanceling booking for 3-007...");
        findSeat(layout, "3-007").cancel();
        printLayout(layout);

	System.out.println("\n=== FINAL UPDATED STATE ===");
	printLayout(layout);


        //System.out.println(atrium);
	//screen1.displayLayout();

    }

    // prints seats like [1-001:A]
    private static void printLayout(Seat[][] layout) {
        int total = 0, available = 0;
        for (int r = 0; r < layout.length; r++) {
            StringBuilder sb = new StringBuilder();
            for (Seat s : layout[r]) {
                sb.append(String.format("[%s:%s] ",
                        s.getId(), s.isAvailable() ? "A" : "X"));
                total++;
                if (s.isAvailable()) available++;
            }
            System.out.println(sb.toString().trim());
        }
        System.out.println("Total: " + total + ", Available: " + available);
    }

    // find seat by ID
    private static Seat findSeat(Seat[][] layout, String id) {
        for (Seat[] row : layout)
            for (Seat s : row)
                if (s.getId().equals(id))
                    return s;
        return null;
    }
}

